namespace Petzold.CircleTheButtons
{
    public enum RadialPanelOrientation
    {
        ByWidth,
        ByHeight
    }
}