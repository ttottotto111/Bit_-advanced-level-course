﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Win32;

namespace Paint
{
    /// <summary>
    /// MainWindow.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class MainWindow : Window
    {
        //Canvas can;
        Point prePosition; 
        Rectangle currentRect;
        Ellipse currentElli;
        Color col = new Color();
        Color backCol = new Color();

        int type = 0;

        bool check = false;
        // ==============================================================================
        //생성자
        public MainWindow()
        {
            InitializeComponent();

            col = Colors.Black;
            backCol = Colors.Transparent;

            this.canvas1.MouseLeftButtonDown += new MouseButtonEventHandler(canvas1_MouseLeftButtonDown);
            this.canvas1.MouseMove += new MouseEventHandler(canvas1_MouseMove);
            this.canvas1.MouseLeftButtonUp += new MouseButtonEventHandler(canvas1_MouseLeftButtonUp);
        }
        // ==============================================================================

        private void canvas1_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (type == 1)
            {
                //마우스의 좌표를 저장한다.          
                prePosition = e.GetPosition(this.canvas1);
                //마우스가 Grid밖으로 나가도 위치를 알 수 있도록 마우스 이벤트를 캡처한다.          
                this.canvas1.CaptureMouse();
                if (currentRect == null)
                {
                    //사각형을 생성한다.              
                    CreteRectangle();
                    check = true;
                }
            }
            else if (type == 2)
            {
                //마우스의 좌표를 저장한다.          
                prePosition = e.GetPosition(this.canvas1);
                //마우스가 Grid밖으로 나가도 위치를 알 수 있도록 마우스 이벤트를 캡처한다.          
                this.canvas1.CaptureMouse();
                if (currentElli == null)
                {
                    //사각형을 생성한다.              
                    CreteEllipse();
                    check = true;
                }
            }
        }

        private void canvas1_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (check == true && canvas1.EditingMode == InkCanvasEditingMode.None)
            {
                //마우스 캡춰를 제거한다.          
                this.canvas1.ReleaseMouseCapture();
                SetRectangleProperty();
                currentRect = null;
                currentElli = null;
                check = false;
            }
        }

        private void canvas1_MouseMove(object sender, MouseEventArgs e)
        {
            //현재 이동한 마우스의 좌표를 얻어온다
            Point currnetPosition = e.GetPosition(this.canvas1);
            //좌표를 표시한다.
            //this.tbPosition.Text = string.Format("마우스 좌표 : [{0},{1}]", currnetPosition.X, currnetPosition.Y);
            //마우스 왼쪽 버튼이 눌려있으면
            if (e.MouseDevice.LeftButton == MouseButtonState.Pressed)
            {
                if (currentRect != null || currentElli != null)
                {
                    //사각형이 나타날 기준점을 설정한다.
                    double left = prePosition.X;
                    double top = prePosition.Y;
                    //마우스의 위치에 따라 적절히 기준점을 변경한다.
                    if (prePosition.X > currnetPosition.X)
                    {
                        left = currnetPosition.X;
                    }
                    if (prePosition.Y > currnetPosition.Y)
                    {
                        top = currnetPosition.Y;
                    }

                    if (type == 1)
                    {
                        //사각형의 위치 기준점(Margin)을 설정한다
                        currentRect.Margin = new Thickness(left, top, 0, 0);
                        //사각형의 크기를 설정한다. 음수가 나올 수 없으므로 절대값을 취해준다.
                        currentRect.Width = Math.Abs(prePosition.X - currnetPosition.X);
                        currentRect.Height = Math.Abs(prePosition.Y - currnetPosition.Y);
                    }
                    else if (type == 2)
                    {
                        //사각형의 위치 기준점(Margin)을 설정한다
                        currentElli.Margin = new Thickness(left, top, 0, 0);
                        //사각형의 크기를 설정한다. 음수가 나올 수 없으므로 절대값을 취해준다.
                        currentElli.Width = Math.Abs(prePosition.X - currnetPosition.X);
                        currentElli.Height = Math.Abs(prePosition.Y - currnetPosition.Y);
                    }
                }
            }
        }

        private void CreteRectangle()
        {                     
            currentRect = new Rectangle();          
            currentRect.Stroke = new SolidColorBrush(col);          
            currentRect.StrokeThickness = 2;          
            currentRect.Opacity = 0.7;          
            //사각형을 그리는 동안은 테두리를 Dash 스타일로 설정한다.          
            DoubleCollection dashSize = new DoubleCollection();          
            dashSize.Add(1);          
            dashSize.Add(1);          
            currentRect.StrokeDashArray = dashSize;          
            currentRect.StrokeDashOffset = 0;          
            //사각형의 정렬 기준을 설정한다.          
            currentRect.HorizontalAlignment = System.Windows.HorizontalAlignment.Left;          
            currentRect.VerticalAlignment = System.Windows.VerticalAlignment.Top;          
            //그리드에 추가한다.          
            this.canvas1.Children.Add(currentRect);      
        }

        private void CreteEllipse()
        {
            currentElli = new Ellipse();
            currentElli.Stroke = new SolidColorBrush(col);
            currentElli.StrokeThickness = 2;
            currentElli.Opacity = 0.7;
            //사각형을 그리는 동안은 테두리를 Dash 스타일로 설정한다.          
            DoubleCollection dashSize = new DoubleCollection();
            dashSize.Add(1);
            dashSize.Add(1);
            currentElli.StrokeDashArray = dashSize;
            currentElli.StrokeDashOffset = 0;
            //사각형의 정렬 기준을 설정한다.          
            currentElli.HorizontalAlignment = System.Windows.HorizontalAlignment.Left;
            currentElli.VerticalAlignment = System.Windows.VerticalAlignment.Top;
            //그리드에 추가한다.          
            this.canvas1.Children.Add(currentElli);
        }

        private void SetRectangleProperty()      
        {
            if (type == 1)
            {
                //사각형의 투명도를 100% 로 설정          
                currentRect.Opacity = 1;
                //사각형의 색상을 지정          
                currentRect.Fill = new SolidColorBrush(backCol);
                //사각형의 테두리를 선으로 지정          
                currentRect.StrokeDashArray = new DoubleCollection();
            }
            else if (type == 2)
            {
                //사각형의 투명도를 100% 로 설정          
                currentElli.Opacity = 1;
                //사각형의 색상을 지정          
                currentElli.Fill = new SolidColorBrush(backCol);
                //사각형의 테두리를 선으로 지정          
                currentElli.StrokeDashArray = new DoubleCollection();
            }
        }

        // ==============================================================================
        // 그리기 종류
        private void button7_Click(object sender, RoutedEventArgs e)
        {
            if (type != 0)
            {
                canvas1.EditingMode = InkCanvasEditingMode.Ink;

                type = 0;
            }
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            if (type != 1)
            {
                canvas1.EditingMode = InkCanvasEditingMode.None;

                type = 1;
            }
        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {
            if( type != 2)
            {
                 canvas1.EditingMode = InkCanvasEditingMode.None;

                type = 2;
            }
        }

        // ==============================================================================
        // 지우기
        private void button8_Click(object sender, RoutedEventArgs e)
        {
            canvas1.Strokes.Clear();
            canvas1.Children.Clear();
        }

        // ==============================================================================
        // 색 버튼
        private void button3_Click(object sender, RoutedEventArgs e)
        {
            col = Colors.Red;
            canvas1.DefaultDrawingAttributes.Color = col;
        }

        private void button4_Click(object sender, RoutedEventArgs e)
        {
            col = Colors.Blue;
            canvas1.DefaultDrawingAttributes.Color = col;
        }

        private void button5_Click(object sender, RoutedEventArgs e)
        {
            col = Colors.Green;
            canvas1.DefaultDrawingAttributes.Color = col;
        }

        private void button6_Click(object sender, RoutedEventArgs e)
        {
            col = Colors.Black;
            canvas1.DefaultDrawingAttributes.Color = col;
        }

        // 배경 색 버튼
        private void button11_Click(object sender, RoutedEventArgs e)
        {
            backCol = Colors.Red;
        }

        private void button12_Click(object sender, RoutedEventArgs e)
        {
            backCol = Colors.Blue;
        }

        private void button13_Click(object sender, RoutedEventArgs e)
        {
            backCol = Colors.Green;
        }

        private void button14_Click(object sender, RoutedEventArgs e)
        {
            backCol = Colors.Black;
        }
        // ===================================================================================
        // 해당 객체를 이미지로 변환
        private static RenderTargetBitmap ConverterBitmapImage(FrameworkElement element)
        {
            DrawingVisual drawingVisual = new DrawingVisual();
            DrawingContext drawingContext = drawingVisual.RenderOpen();

            // 해당 객체의 그래픽요소로 사각형의 그림을 그립니다.
            drawingContext.DrawRectangle(new VisualBrush(element), null,
                new Rect(new Point(0, 0), new Point(element.ActualWidth, element.ActualHeight)));

            drawingContext.Close();

            // 비트맵으로 변환합니다.
            RenderTargetBitmap target =
                new RenderTargetBitmap((int)element.ActualWidth, (int)element.ActualHeight,
                96, 96, System.Windows.Media.PixelFormats.Pbgra32);

            target.Render(drawingVisual);
            return target;
        }

        // 해당 이미지 저장
        private static void ImageSave(BitmapSource source)
        {
            SaveFileDialog saveDialog = new SaveFileDialog();

            // 이미지 포맷들
            saveDialog.Filter = "PNG|*.png|JPG|*.jpg|GIF|*.gif|BMP|*.bmp";
            saveDialog.AddExtension = true;

            if (saveDialog.ShowDialog() == true)
            {
                BitmapEncoder encoder = null;
                // 파일 생성
                FileStream stream = new FileStream(saveDialog.FileName, FileMode.Create, FileAccess.Write);

                // 파일 포맷
                string upper = saveDialog.SafeFileName.ToUpper();
                char[] format = upper.ToCharArray(saveDialog.SafeFileName.Length - 3, 3);
                upper = new string(format);

                // 해당 포맷에 맞게 인코더 생성
                switch (upper.ToString())
                {
                    case "PNG":
                        encoder = new PngBitmapEncoder();
                        break;

                    case "JPG":
                        encoder = new JpegBitmapEncoder();
                        break;

                    case "GIF":
                        encoder = new GifBitmapEncoder();
                        break;

                    case "BMP":
                        encoder = new BmpBitmapEncoder();
                        break;
                }

                // 인코더 프레임에 이미지 추가
                encoder.Frames.Add(BitmapFrame.Create(source));
                // 파일에 저장
                encoder.Save(stream);

                stream.Close();
            }
        }

        // ===================================================================================
        // 저장
        private void button9_Click(object sender, RoutedEventArgs e)
        {
            RenderTargetBitmap bitmap = ConverterBitmapImage(canvas1);
            ImageSave(bitmap);
        }

        // 불러오기
        private void button10_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openDialog = new OpenFileDialog();

            if (openDialog.ShowDialog() == true)
            {
                if (File.Exists(openDialog.FileName))
                {
                    BitmapImage bitmapImage = new BitmapImage(new Uri(openDialog.FileName,
                        UriKind.RelativeOrAbsolute));

                    // InkCanvas의 배경으로 지정
                    canvas1.Background = new ImageBrush(bitmapImage);
                }
            }
        }
        // ===================================================================================
    }
}
