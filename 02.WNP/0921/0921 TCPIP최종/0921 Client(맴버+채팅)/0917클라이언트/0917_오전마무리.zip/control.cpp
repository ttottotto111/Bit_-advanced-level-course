//control.cpp

#include "std.h"

#define SERVER_IP	"127.0.0.1" //61.81.98.100
#define SERVER_PORT 9000

BOOL g_isConnect	= FALSE;
BOOL g_isLogin		= FALSE;


void con_NewMember(HWND hDlg)
{
	//���
	UINT ret = DialogBoxParam(GetModuleHandle(0),// hinstance
		MAKEINTRESOURCE(IDD_DIALOG2),
		hDlg, // �θ�
		NewMemberDlgProc, // �޼��� �Լ�.
		(LPARAM)0); // WM_INITDIALOG�� lParam�� ���޵ȴ�.
	if (ret == IDOK)
	{
	
	}
}

void con_Login(HWND hDlg)
{
	TCHAR id[20], pw[20];
	GetDlgItemText(hDlg, IDC_EDIT1, id, sizeof(id));
	GetDlgItemText(hDlg, IDC_EDIT2, pw, sizeof(pw));

	g_isLogin = TRUE;
}

void con_LogOut(HWND hDlg)
{
	g_isLogin = FALSE;
}

void con_ConectServer(HWND hDlg)
{
	g_isConnect = FALSE;
}

void con_DisConnectServer(HWND hDlg)
{
	g_isConnect = FALSE;
}

void con_SendData(HWND hDlg)
{
	TCHAR msg[50];
	GetDlgItemText(hDlg, IDC_EDIT7, msg, sizeof(msg));
}

void con_Cancel(HWND hDlg)
{
	EndDialog(hDlg, IDCANCEL);
}