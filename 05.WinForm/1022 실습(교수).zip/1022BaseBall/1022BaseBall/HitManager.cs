﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1022BaseBall
{
    class HitManager
    {
        #region 싱글톤
        //1. 생성자 은닉
        private HitManager()
        {
        }
        //2. 프로퍼티 선언
        static public HitManager Singleton { get; private set; }
        //3. static 생성자에서 객체 생성(단 한번 호출되는 문장)
        static HitManager()
        {
            Singleton = new HitManager();
        }
        #endregion

        private Dictionary<int, Hitter> hitlist = new Dictionary<int, Hitter>();
        
        public HitPosition IntToHitPosition(int idx)
        {
            HitPosition ht;
            switch(idx)
            {
                case 0:     ht = HitPosition.NON;       break;
                case 1:     ht = HitPosition.BASE1;     break;
                case 2:     ht = HitPosition.BASE2;     break;
                case 3:     ht = HitPosition.BASE3;     break;
                case 4:     ht = HitPosition.SORTSTOP;  break;
                case 5:     ht = HitPosition.LEFTWING;  break;
                case 6:     ht = HitPosition.RIGHTWING; break;
                case 7:     ht = HitPosition.CENTERFILTER; break;
                case 8:     ht = HitPosition.CATER;     break;
                default:    ht = HitPosition.NON;       break;
            }
            return ht;
        }

        public HitType IntToHitType(int idx)
        {
            HitType type;
            switch (idx)
            {
                case 0: type = HitType.NON; break;
                case 1: type = HitType.LEFT; break;
                case 2: type = HitType.RIGHT; break;
                case 3: type = HitType.BOTH; break;
                default:   type = HitType.NON; break;
            }
            return type;
        }

        //유일한 ID생성
        public int MakeHitterID()
        {  
            Random r = new Random();
            int rvalue;
            while (true)
            {                
                rvalue = r.Next(0, 100);
                if (hitlist.ContainsKey(rvalue) == false)
                    break;               
            }
            return rvalue;
        }

        //선수 생성
        public bool InsertHitter(int id, string name, HitPosition position, HitType type)
        {
            try
            {
                Hitter man = new Hitter(id, name, position, type);
                hitlist.Add(id, man);

                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        //선수 검색(등번호)
        public Hitter IdToHitter(int key)
        {
            return hitlist[key];
        }

        //선수 검색(이름)
        public List<Hitter>  NameToHitter(string name)
        {
            List<Hitter> temp = new List<Hitter>();

            foreach (KeyValuePair<int, Hitter> data in hitlist)
            {
                if (data.Value.Name.Equals(name) == true)
                {
                    temp.Add(data.Value);
                }
            }
            return temp;
        }
    }
}
