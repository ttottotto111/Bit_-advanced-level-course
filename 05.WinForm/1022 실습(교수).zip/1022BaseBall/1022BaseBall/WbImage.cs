﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace _1022BaseBall
{
    class WbImageData
    {
        public Rectangle Rect { get; set; }
        public string Msg { get; set; }

        public WbImageData(Rectangle r, string msg)
        {
            Rect = r;
            Msg = msg;
        }
    }

    class WbImage
    {
        private static List<WbImageData> datalist = new List<WbImageData>();

        #region 선수 생성
        //야구장 그리기-선수 생성
        //Form1의 Load 이벤트에서 호출        
        public static void DrawGround(Panel panel1)
        {
            try
            {
                // 이미지 변환
                Bitmap sourceImage = new Bitmap("야구장.png");
                Size resize = new Size(panel1.Width, panel1.Height);
                Bitmap resizeImage = new Bitmap(sourceImage, resize);
                panel1.BackgroundImage = resizeImage;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "에러발생");
            }
        }

        //선수 표시하기
        public static void DrawHitter(Panel panel1, HitPosition position, int id, string name)
        {
            Rectangle r = new Rectangle(0, 0, 10, 10); 
            switch (position)
            {
                case HitPosition.BASE1: r.X= 340; r.Y = 210; break;
                case HitPosition.BASE2: r.X= 260; r.Y = 170; break;
                case HitPosition.BASE3: r.X= 190; r.Y = 215; break;
                case HitPosition.SORTSTOP: r.X= 211; r.Y = 175; break;
                case HitPosition.LEFTWING: r.X = 130; r.Y = 120; break;
                case HitPosition.RIGHTWING: r.X = 429; r.Y = 120; break;
                case HitPosition.CENTERFILTER: r.X = 274; r.Y = 81; break;
                case HitPosition.CATER: r.X = 260; r.Y = 270; break;
            }

            datalist.Add(new WbImageData(r, string.Format("{1},{0}", id, name)));            
        }
            
        public static void DrawHitter(Graphics g)
        {

            foreach(WbImageData data in datalist)
            {
                g.FillEllipse(new SolidBrush(Color.Crimson), data.Rect);
                g.DrawString(data.Msg, new Font("Timesroman", 12), new SolidBrush(Color.Blue), data.Rect.X, data.Rect.Y);

            }
        }

        #endregion

        #region 연산
        //야구장 그리기-연산
        //Form1의 Load 이벤트에서 호출
        public static void DrawGround1(Panel panel2)
        {
            try
            {
                // 이미지 변환
                Bitmap sourceImage = new Bitmap("야구장.png");
                Size resize = new Size(panel2.Width, panel2.Height);
                Bitmap resizeImage = new Bitmap(sourceImage, resize);
                panel2.BackgroundImage = resizeImage;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "에러발생");
            }
        }

        //선수 위치 표시
        public static void DrawHitterRun(Panel panel, Hitter ht)
        {
            using (Graphics g = panel.CreateGraphics())
            {
                Rectangle r = new Rectangle(0, 0, 10, 10);
                switch (ht.Type)
                {
                    case HitType.LEFT: r.X = 170; r.Y = 265; break;
                    case HitType.RIGHT:r.X = 198; r.Y = 265; break;
                    case HitType.BOTH:
                        {
                            Random ran = new Random();
                            if (ran.Next(0, 2) == 0)
                            {
                                r.X = 170; r.Y = 280;
                            }
                            else
                            {
                                r.X = 198; r.Y = 280;
                            }
                        }
                        break;
                }
                g.FillEllipse(new SolidBrush(Color.Crimson), r);
                g.DrawString(string.Format("{0} {1}",ht.Id, ht.Name), 
                    new Font("Timesroman", 12), 
                    new SolidBrush(Color.Blue), r.X, r.Y+10);
            }

        }

        #endregion 

        public static void TestImage(Panel panel, Hitter hit)
        {
            using (Graphics g = panel.CreateGraphics())
            {
                Rectangle r = new Rectangle(0, 0, 10, 10);
                Random ran = new Random();
                switch (hit.Type)
                {
                    case HitType.LEFT:  r = new Rectangle(170, 265, 10, 10); break;
                    case HitType.RIGHT: r = new Rectangle(198, 265,10,10); break;
                    case HitType.BOTH:
                        {
                            
                            if (ran.Next(0, 2) == 0)
                            {
                                r = new Rectangle(170, 265, 10, 10);
                            }
                            else
                            {
                                r = new Rectangle(198, 265, 10, 10);
                            }
                        }
                        break;
                }
                
                for(int i=0; i<ran.Next(5,20); i++)
                {
                    g.FillEllipse(new SolidBrush(Color.Crimson), r);
                    r.Y -= 10;
                    Thread.Sleep(50);
                }
                Thread.Sleep(1000);
                //panel.Invalidate();                
            }
        }
    }
}
