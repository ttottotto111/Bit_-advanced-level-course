﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1022BaseBall
{
    /// <summary>
    /// 계좌 타입
    /// </summary>
    public enum HitPosition
    {
        NON = 0,
        BASE1 = 1,
        BASE2 = 2,
        BASE3 = 3,
        SORTSTOP = 4,
        LEFTWING = 5,
        RIGHTWING = 6,
        CENTERFILTER = 7,
        CATER = 8,
    }

    public enum HitType
    {
        NON = 0,
        LEFT = 1,
        RIGHT = 2,
        BOTH = 3
    }

    public class Hitter
    {
        #region 프로퍼티 
        
        private readonly int id;
        public int Id { get { return id; } }

        private readonly string name;
        public string Name { get { return name; } }

        public HitPosition Position { get; set; }

        public HitType Type { get; set; }

        public int Hit1 { get; set; }

        public int Hit2 { get; set; }

        public int Hit3 { get; set; }

        public int HomRun { get; set; }

        public int Balls { get; set; }

        public int DBall { get; set; }

        public int SOut { get; set; }

        public int Out { get; set; }

        public int GameCount { get; set; }

        public int HitCount { get; set; }

        public float Average { get; set; }

        #endregion

        #region 생성자 
        
        public Hitter(int _id, string _name, HitPosition _position, HitType _type)
        {
            id = _id;
            name = _name;
            Position = _position;
            Type = _type;

            Hit1 = Hit2 = Hit3 = HomRun = Balls = SOut = Out = GameCount = HitCount = 0;
            Average = 0.0f;
        }
        #endregion

        #region 메서드
            /*
             * 타율 = 안타/타수

            ex) 100안타 , 270타수 -> 0.370

            단, 4구(四球 볼넷), 사구(死球)로 나갔을 경우는 타수로 계산하지 않는다. 

            경기수    : 안타~아웃 모든 값들의 합 / 5(정수) -> 소수점은 제외 
            타수       : 안타~아웃 모든 값들의 합(제외 : 볼넷, 사구는 제외) -> 정수
            타율       : 안타 / 타수  -> 실수 
            */
        public void Update()
        {
            GameCount   = (Hit1 + Hit2 + Hit3 + HomRun + Balls + DBall + SOut + Out)/5;
            HitCount    = Hit1 + Hit2 + Hit3 + HomRun + SOut + Out;
            Average = (Hit1 + Hit2 + Hit3 + HomRun) / (float)HitCount;
        }
        #endregion
    }
}
