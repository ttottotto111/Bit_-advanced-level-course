﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1022BaseBall
{
    public partial class Form1 : Form
    {
        Hitter hitter1;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.SelectedIndex = 0;
            comboBox2.SelectedIndex = 0;
            comboBox4.SelectedIndex = 0;

            WbImage.DrawGround(panel1);
            WbImage.DrawGround1(panel2);
        }

        #region 선수 생성

        //등번호 생성 버튼
        private void button1_Click(object sender, EventArgs e)
        {
            int id = HitManager.Singleton.MakeHitterID();
            textBox1.Text = id.ToString();
        }

        //선수 생성 버튼
        private void button2_Click(object sender, EventArgs e)
        {
            int id = int.Parse(textBox1.Text);
            string name = textBox2.Text;
            HitPosition position = HitManager.Singleton.IntToHitPosition(comboBox1.SelectedIndex);
            HitType type = HitManager.Singleton.IntToHitType(comboBox2.SelectedIndex);

            if (HitManager.Singleton.InsertHitter(id, name, position, type) == false)
                MessageBox.Show("선수 생성 실패(ID중복)");
            else
            {
                textBox1.Text = "";
                textBox2.Text = "";
                comboBox1.SelectedIndex = 0;
                comboBox2.SelectedIndex = 0;

                //선수 표시하기
                WbImage.DrawHitter(panel1, position, id, name);
                panel1.Invalidate();
            }
        }

        //무효화 처리-이미지 출력
        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            WbImage.DrawHitter(e.Graphics);
        }


        #endregion
        
        #region 선수 검색[좌상단 기능]

        //검색정보 변경
        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            //정기입금액 UI처리(활성, 비활성)
            if (comboBox4.SelectedIndex == 0)
                label6.Text = "ID(등번호)";
            else
                label6.Text = "이름";
        }

        //검색 요청
        private void button3_Click(object sender, EventArgs e)
        {
            try
            {               

                if (comboBox4.SelectedIndex == 0)   //ID(등번호)
                {
                    int key = int.Parse(textBox3.Text);
                    Hitter hitman = HitManager.Singleton.IdToHitter(key);
                    HitListPrint(hitman);
                }
                else //이름
                {
                    string key = textBox3.Text;
                    List<Hitter> hitlist = HitManager.Singleton.NameToHitter(key);
                    HitListPrint(hitlist);
                }
            }
            catch (Exception)
            {
            }
        }

        private void HitListPrint(Hitter hitman)
        {
            listBox1.Items.Clear();
            listBox1.Items.Add(hitman.Id);
        }

        private void HitListPrint(List<Hitter> hitman)
        {
            listBox1.Items.Clear();
            foreach (Hitter data in hitman)
            {
                listBox1.Items.Add(data.Id);
            }
        }

        #endregion
        
        #region 선수 검색[좌하단 기능]
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int id = int.Parse(listBox1.SelectedItem.ToString());
            Hitter ht = HitManager.Singleton.IdToHitter(id);

            //오른쪽에 적절히 출력
            HitInfoTopPrint(ht);
            HitInfoBottomPrint(ht);
            //연산 창에 출력
            UpdateData(ht);
        }

        private void HitInfoTopPrint(Hitter hitman)
        {
            textBox4.Text = hitman.Id.ToString();
            textBox5.Text = hitman.Name;
            textBox6.Text = hitman.Position.ToString();
            textBox7.Text = hitman.Type.ToString();
            textBox8.Text = hitman.GameCount.ToString();
            textBox10.Text = hitman.HitCount.ToString();
            textBox11.Text = hitman.Average.ToString();
        }

        private void HitInfoBottomPrint(Hitter ht)
        {
            listView1.Items.Clear();
            listView1.Items.Add(new ListViewItem(new string[] {
                  ht.Id.ToString(),ht.Hit1.ToString(), ht.Hit2.ToString(), ht.Hit3.ToString(),
                  ht.HomRun.ToString(), ht.Balls.ToString(), ht.DBall.ToString(),
                  ht.SOut.ToString(), ht.Out.ToString()
            }));            
        }
        #endregion

        #region 선수 검색[우상단 기능]

        //연산 버튼 클릭
        private void button4_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 2;
        }

        #endregion

        #region 연산

        //좌측 타자 정보 출력
        //[선수 검색[좌하단 기능]listBox1_SelectedIndexChanged에서 호출됨.
        public void UpdateData(Hitter ht)   //[public] class Hitter [public]enum XXX
        {
            textBox9.Text = ht.Id.ToString();
            textBox12.Text = ht.Name;
            textBox13.Text = ht.Position.ToString();
            textBox14.Text = ht.Type.ToString();
            textBox15.Text = ht.GameCount.ToString();
            textBox16.Text = ht.HitCount.ToString();
            textBox17.Text = ht.Average.ToString();

            listView2.Items.Clear();
            listView2.Items.Add(new ListViewItem(new string[] {
                  ht.Id.ToString(),ht.Hit1.ToString(), ht.Hit2.ToString(), ht.Hit3.ToString(),
                  ht.HomRun.ToString(), ht.Balls.ToString(), ht.DBall.ToString(),
                  ht.SOut.ToString(), ht.Out.ToString()
            }));

            PrintHitter(ht);
            hitter1 = ht;
        }

        //우측 연산 수행
        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            int idx = comboBox3.SelectedIndex;
            Hitter ht = HitManager.Singleton.IdToHitter(int.Parse(textBox9.Text));

            switch (idx)
            {
                case 0: break;
                case 1: ht.Hit1++;      break;
                case 2: ht.Hit2++;      break;
                case 3: ht.Hit3++;      break;
                case 4: ht.HomRun++;    break;
                case 5: ht.Balls++;     break;
                case 6: ht.DBall++;     break;
                case 7: ht.SOut++;      break;
                case 8: ht.Out++;       break;
            }
            ht.Update();
            UpdateData(ht);
        }

        //이미지 출력-타석
        //UpdateData에서 호출
        public void PrintHitter(Hitter ht)
        {
            Invalidate();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {
            WbImage.DrawHitterRun(panel2, hitter1);
        }

        //test
        private void button5_Click(object sender, EventArgs e)
        {
            WbImage.TestImage(panel2, hitter1);
        }
        #endregion


    }
}
