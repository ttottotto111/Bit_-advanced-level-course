﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace WindowsFormsApplication4
{

    public partial class Form1 : Form
    {
        //================== delegate =============================
        public delegate void ShowModalesss();
        public ShowModalesss myDelegate;
        //===========================================================
        public Form2 frm = null;
        public Form1()
        {
            InitializeComponent();
            //=============== delegate 초기화 ===========================
            myDelegate = new ShowModalesss(modalesscreate);
            //========================================================
        }
       
        private void button1_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1();
            Thread th = new Thread(new ParameterizedThreadStart(form.foo));
            th.Start(this); 
        }
         
        // thread 함수 
        public void foo(object temp)
        {
            Form1 f = (Form1)temp;
            MyThreadClass myThreadClassObject = new MyThreadClass(f);
            myThreadClassObject.Run();
        }

        //============ delegate 호출함수 ==========================
        public void modalesscreate()
        {
            frm =  new Form2();
            frm.Text = "모덜리스 예제";
            frm.Size = new Size(200, 200);
            frm.Show();
        }    
    }

    //======= invoke 처리 클래스 ==========================
    public class MyThreadClass
    {
        Form1 myFormControl1;
        public MyThreadClass(Form1 myForm)
        {
            myFormControl1 = myForm;
        }
        public void Run()
        {
            // Execute the specified delegate on the thread that owns
            // 'myFormControl1' control's underlying window handle.
            myFormControl1.Invoke(myFormControl1.myDelegate);
        }
    }
    //=========================================================

}
